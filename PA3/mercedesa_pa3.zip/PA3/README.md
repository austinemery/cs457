# PA3

To Run:
```
  $ make
  $ ./PA3
```

For a list of commands do while running:
```
  $ COMMANDS
```

# Austin is the bees knees
# Mercedes is the coolest cat
# Nick is a hawt dawg
